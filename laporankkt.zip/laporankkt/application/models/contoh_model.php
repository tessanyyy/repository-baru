<?php

class Contoh_model extends CI_model {
	public function get_data()
	{
		
	}
}

?>