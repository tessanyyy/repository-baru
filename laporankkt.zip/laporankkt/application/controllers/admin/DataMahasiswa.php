<?php

class DataMahasiswa extends CI_Controller{
	public function index()
	{
		$data['title'] = "Data Mahasiswa";
		$data['mahasiswa'] = $this->laporankktModel->get_data('data_mahasiswa')->result();
		$this->load->view('templates_admin/header', $data);
		$this->load->view('templates_admin/sidebar');
		$this->load->view('admin/dataMahasiswa', $data);
		$this->load->view('templates_admin/footer');
	}
	public function tambahData()
	{
		$data['title'] = "Tambah Data Mahasiswa";
		$this->load->view('templates_admin/header', $data);
		$this->load->view('templates_admin/sidebar');
		$this->load->view('admin/tambahDataMahasiswa', $data);
		$this->load->view('templates_admin/footer');
	}
	public function tambahDataAksi()
	{
		$this->_rules();

		if($this->form_validation->run() == FALSE) {
			$this->tambahData();
		}else{
			$nim			= $this->input->post('nim');
			$nama_mahasiswa	= $this->input->post('nama_mahasiswa');
			$jurusan		= $this->input->post('jurusan');
			$posko_kkt		= $this->input->post('posko_kkt');

			$data = array(

				'nim'				=> $nim,
				'nama_mahasiswa'	=> $nama_mahasiswa,
				'jurusan'			=> $jurusan,
				'posko_kkt'				=> $posko_kkt,
			);

			$this->laporankktModel->insert_data($data,'data_mahasiswa');
			$this->session->set_flashdata('pesan','<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>Data berhasil di tambahkan!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span>
				</button>
				</div>');
				redirect('admin/dataMahasiswa');
		}
	}

	public function updateData($id)
	{
		$where = array('id_mahasiswa' => $id);
		$data['dataMahasiswa'] = $this->db->query("SELECT * FROM data_mahasiswa WHERE id_mahasiswa='$id'")->result();
		$data['title'] = "Tambah Data Laporan";
		$this->load->view('templates_admin/header', $data);
		$this->load->view('templates_admin/sidebar');
		$this->load->view('admin/updateDataMahasiswa', $data);
		$this->load->view('templates_admin/footer');
	}

	public function updateDataAksi()
	{
		$this->_rules();

		if($this->form_validation->run() == FALSE) {
			$this->updateData();
		}else{
			$id 				= $this->input->post('id_mahasiswa');
			$nim 				= $this->input->post('nim');
			$nama_mahasiswa		= $this->input->post('nama_mahasiswa');
			$jurusan			= $this->input->post('jurusan');
			$posko_kkt				= $this->input->post('posko_kkt');

			$data = array(

				'nim'				=> $nim,
				'nama_mahasiswa'	=> $nama_mahasiswa,
				'jurusan'			=> $jurusan,
				'posko_kkt'				=> $posko_kkt,
			);

			$where = array(
				'id_mahasiswa' => $id
			);

			$this->laporankktModel->update_data('data_mahasiswa',$data,$where);
			$this->session->set_flashdata('pesan','<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>Data berhasil di update!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span>
				</button>
				</div>');
				redirect('admin/dataMahasiswa');
		}
	}

	public function _rules()
	{
		$this->form_validation->set_rules('nim','nim','required');
		$this->form_validation->set_rules('nama_mahasiswa','nama_mahasiswa','required');
		$this->form_validation->set_rules('jurusan','jurusan','required');
		$this->form_validation->set_rules('posko_kkt','posko_kkt','required');
	}

	public function deleteData($id)
	{
		$where = array('id_mahasiswa' => $id);
		$this->laporankktModel->delete_data($where, 'data_mahasiswa');
		$this->session->set_flashdata('pesan','<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<strong>Data berhasil dihapus!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span>
				</button>
				</div>');
				redirect('admin/dataMahasiswa');
	}
}

?>