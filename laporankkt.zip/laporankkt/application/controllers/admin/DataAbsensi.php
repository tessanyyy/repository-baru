<?php

class DataAbsensi extends CI_Controller{

		public function index()
	{
		$data['title'] = "Data Absensi Peserta KKT";

		if((isset($_GET['bulan']) && $_GET['bulan']!='') && (isset($_GET['tahun']) && $_GET['tahun']!='')){
			$bulan = $_GET['bulan'];
			$tahun = $_GET['tahun'];
			$bulantahun = $bulan.$tahun;
		}else{
			$bulan = date('m');
			$tahun = date('Y');
			$bulantahun = $bulan.$tahun;
		}


		$data ['absensi'] = $this->db->query("SELECT data_kehadiran.*, data_mahasiswa.nama_mahasiswa, data_mahasiswa.nim, data_mahasiswa.posko_kkt FROM data_kehadiran INNER JOIN data_mahasiswa ON data_kehadiran.nim=data_mahasiswa.nim
			INNER JOIN data_laporanharian ON data_mahasiswa.posko_kkt = data_laporanharian.posko
			WHERE data_kehadiran.bulan='$bulantahun'
			ORDER BY data_mahasiswa.nama_mahasiswa ASC")->result();
		$this->load->view('templates_admin/header', $data);
		$this->load->view('templates_admin/sidebar');
		$this->load->view('admin/dataAbsensi', $data);
		$this->load->view('templates_admin/footer');
	}
}

?>