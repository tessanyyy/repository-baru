<?php

class DataLaporanakhir extends CI_Controller{

	public function index()
	{
		$data['title'] = "Data Laporan Akhir";
		$data['laporanAkhir'] = $this->laporankktModel->get_data('data_laporanakhir')->result();
		$this->load->view('templates_admin/header', $data);
		$this->load->view('templates_admin/sidebar');
		$this->load->view('admin/dataLaporanakhir', $data);
		$this->load->view('templates_admin/footer');
	}
}

?>