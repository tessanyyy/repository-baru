<?php

class DataLaporanharian extends CI_Controller{

	public function index()
	{
		$data['title'] = "Data Laporan Harian";
		$data['mahasiswa'] = $this->laporankktModel->get_data('data_mahasiswa')->result();
		$data['laporanHarian'] = $this->laporankktModel->get_data('data_laporanharian')->result();
		$this->load->view('templates_admin/header', $data);
		$this->load->view('templates_admin/sidebar');
		$this->load->view('admin/dataLaporanharian', $data);
		$this->load->view('templates_admin/footer');
	}

	public function tambahData()
	{
		$data['title'] = "Tambah Data Laporan";
		$data['mahasiswa'] = $this->laporankktModel->get_data('data_mahasiswa')->result();
		$this->load->view('templates_admin/header', $data);
		$this->load->view('templates_admin/sidebar');
		$this->load->view('admin/tambahDataLaporanharian', $data);
		$this->load->view('templates_admin/footer');
	}

	public function tambahDataAksi()
	{
		$this->_rules();

		if($this->form_validation->run() == FALSE) {
			$this->tambahData();
		}else{
			$tanggal_laporan	= $this->input->post('tanggal_laporan');
			$posko				= $this->input->post('posko');
			$dpl				= $this->input->post('dpl');
			$dosen_pengawas		= $this->input->post('dosen_pengawas');
			$komentar_kegiatan	= $this->input->post('komentar_kegiatan');
			$laporan			= $_FILES['laporan']['name'];
			if($laporan=''){}else{
				$config ['upload_path']	= './assets/filelaporan';
				$config ['allowed_types'] = 'pdf';
				$this->load->library('upload', $config);
				if(!$this->upload->do_upload('laporan')){
					echo "Laporan Gagal diupload";
				}else{
					$photo=$this->upload->data('file_name');
				}
			}

			$data = array(

				'tanggal_laporan'	=> $tanggal_laporan,
				'posko'				=> $posko,
				'dpl'				=> $dpl,
				'dosen_pengawas'	=> $dosen_pengawas,
				'komentar_kegiatan'	=> $komentar_kegiatan,
				'laporan'			=> $laporan,
			);

			$this->laporankktModel->insert_data($data,'data_laporanharian');
			$this->session->set_flashdata('pesan','<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>Data berhasil di tambahkan!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span>
				</button>
				</div>');
				redirect('admin/dataLaporanharian');
		}
	}

		public function updateData($id)
	{
		$where = array('id_laporanharian' => $id);
		$data['mahasiswa'] = $this->laporankktModel->get_data('data_mahasiswa')->result();
		$data['title'] = 'Update Data Pegawai';
		$data['laporanHarian'] = $this->db->query("SELECT * FROM data_laporanharian WHERE id_laporanharian='$id'")->result();
		$data['title'] = "Tambah Data Laporan";
		$this->load->view('templates_admin/header', $data);
		$this->load->view('templates_admin/sidebar');
		$this->load->view('admin/updateDataLaporanharian', $data);
		$this->load->view('templates_admin/footer');
	}

	public function updateDataAksi()
	{
		$this->_rules();

		if($this->form_validation->run() == FALSE) {
			$this->updateData();
		}else{
			$id 				= $this->input->post('id_laporanharian');
			$tanggal_laporan	= $this->input->post('tanggal_laporan');
			$posko				= $this->input->post('posko');
			$dpl				= $this->input->post('dpl');
			$dosen_pengawas		= $this->input->post('dosen_pengawas');
			$komentar_kegiatan	= $this->input->post('komentar_kegiatan');
			$laporan			= $this->input->post('laporan');

			$data = array(

				'tanggal_laporan'	=> $tanggal_laporan,
				'posko'				=> $posko,
				'dpl'				=> $dpl,
				'dosen_pengawas'	=> $dosen_pengawas,
				'komentar_kegiatan'	=> $komentar_kegiatan,
				'laporan'			=> $laporan,
			);

			$where = array(
				'id_laporanharian' => $id
			);

			$this->laporankktModel->update_data('data_laporanharian',$data,$where);
			$this->session->set_flashdata('pesan','<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>Data berhasil di update!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span>
				</button>
				</div>');
				redirect('admin/dataLaporanharian');
		}
	}

	public function _rules()
	{
		$this->form_validation->set_rules('tanggal_laporan','tanggal_laporan','required');
		$this->form_validation->set_rules('posko','posko','required');
		$this->form_validation->set_rules('dpl','dpl','required');
		$this->form_validation->set_rules('dosen_pengawas','dosen_pengawas','required');
		$this->form_validation->set_rules('komentar_kegiatan','komentar_kegiatan','required');
		$this->form_validation->set_rules('laporan','laporan','required');
	}

		public function deleteData($id)
	{
		$where = array('id_laporanharian' => $id);
		$this->laporankktModel->delete_data($where, 'data_laporanharian');
		$this->session->set_flashdata('pesan','<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<strong>Data berhasil dihapus!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span>
				</button>
				</div>');
				redirect('admin/dataLaporanharian');
	}
}

?>