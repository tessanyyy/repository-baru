<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>


    <a class="btn btn-sm btn-success mb-3" href="<?php echo base_url('admin/dataLaporanharian/tambahData') ?>"><i class="fas fa-plus">Tambah Laporan</i></a>
    <?php echo $this->session->flashdata('pesan')?>
    <table class="table table-bordered table-striped mt-2">
    	<tr>
    		<th class="text-center">No</th>
    		<th class="text-center">Tanggal Laporan</th>
    		<th class="text-center">Posko</th>
    		<th class="text-center">DPL</th>
    		<th class="text-center">Dosen Pengawas</th>
    		<th class="text-center">Komentar Kegiatan</th>
            <th class="text-center">Laporan</th>
    		<th class="text-center">Action</th>
    	</tr>

    	<?php  $no=1; foreach($laporanHarian as $l) : ?>
    		<tr>
    			<td><?php echo $no++ ?></td>
    			<td><?php echo $l->tanggal_laporan?></td>
    			<td><?php echo $l->posko?></td>
    			<td><?php echo $l->dpl?></td>
    			<td><?php echo $l->dosenpengawas?></td>
    			<td><?php echo $l->komentarkegiatan?></td>
                <td></td>
                <td>
    				<center>
    					<a class="btn btn-sm btn-primary" href="<?php echo base_url('admin/dataLaporanharian/updateData/'.$l->id_laporanharian) ?>"><i class="fas fa-edit"></i></a>
    					<a onclick="return confirm('Yakin Hapus')" class="btn btn-sm btn-danger" href="<?php echo base_url('admin/dataLaporanharian/deleteData/'.$l->id_laporanharian) ?>"><i class="fas fa-trash"></i></a>
    				</center>
    			</td>
    		</tr>
    	<?php endforeach; ?>
    </table>


</div>