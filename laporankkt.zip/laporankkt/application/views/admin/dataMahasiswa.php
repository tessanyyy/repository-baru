<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>


    <a class="btn btn-sm btn-success mb-3" href="<?php echo base_url('admin/dataMahasiswa/tambahData') ?>"><i class="fas fa-plus">Tambah Data</i></a>
    <?php echo $this->session->flashdata('pesan')?>
    <table class="table table-bordered table-striped mt-2">
    	<tr>
    		<th class="text-center">No</th>
    		<th class="text-center">NIM</th>
    		<th class="text-center">Nama Mahasiswa</th>
    		<th class="text-center">Jurusan</th>
    		<th class="text-center">Posko</th>
    	</tr>

    	<?php  $no=1; foreach($mahasiswa as $m) : ?>
    		<tr>
    			<td><?php echo $no++ ?></td>
    			<td><?php echo $m->nim?></td>
    			<td><?php echo $m->nama_mahasiswa?></td>
    			<td><?php echo $m->jurusan?></td>
    			<td><?php echo $m->posko_kkt?></td>
    			<td>
                    <center>
                        <a class="btn btn-sm btn-primary" href="<?php echo base_url('admin/dataMahasiswa/updateData/'.$m->id_mahasiswa) ?>"><i class="fas fa-edit"></i></a>
                        <a onclick="return confirm('Yakin Hapus')" class="btn btn-sm btn-danger" href="<?php echo base_url('admin/dataMahasiswa/deleteData/'.$m->id_mahasiswa) ?>"><i class="fas fa-trash"></i></a>
                    </center>
    			</td>
    		</tr>
    	<?php endforeach; ?>
    </table>


</div>