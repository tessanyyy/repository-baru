
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>


    <div class="card" style="width: 60%; margin-bottom: 100px">
    	<div class="card-body">
    		
    		<form method="POST" action="<?php echo base_url('admin/dataLaporanharian/tambahDataAksi')?>" enctype="multipart/form-data">

    			<div class="form-group">
    				<label>Tanggal Laporan</label>
    				<input type="date" name="tanggal_laporan" class="form-control">
    				<?php echo form_error('tanggal_laporan', '<div class="text-small text-danger"></div>') ?>
    			</div>

    			<div class="form-group">
    				<label>Posko</label>
    				<select name="posko" class="form-control">
                    <option value="">--Pilih Posko--</option>
                    <?php foreach($mahasiswa as $m) : ?> 
                    <option value="<?php echo $m->posko_kkt ?>"><?php echo $m->posko_kkt ?></option>
                    <?php endforeach; ?>           
                    </select>
    			</div>

    			<div class="form-group">
    				<label>DPL</label>
    				<input type="text" name="DPL" class="form-control">
    				<?php echo form_error('dpl', '<div class="text-small text-danger"></div>')?>
    			</div>

    			<div class="form-group">
    				<label>Dosen Pengawas</label>
    				<input type="text" name="dosen_pengawas" class="form-control">
    				<?php echo form_error('dosen_pengawas', '<div class="text-small text-danger"></div>')?>
    			</div>

    			<div class="form-group">
    				<label>Komentar Kegiatan</label>
    				<input type="text" name="komentar_kegiatan" class="form-control">
    				<?php echo form_error('komentar_kegiatan', '<div class="text-small text-danger"></div>')?>
    			</div>

                <div class="form-group">
                    <label>Laporan</label>
                    <input type="file" name="laporan" class="form-control">
                    <?php echo form_error('laporan', '<div class="text-small text-danger"></div>')?>
                </div>

    			<button type="submit" class="btn btn-success">Submit</button>

    	</div>
    </div>


</div>



