
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>


    <div class="card" style="width: 60%; margin-bottom: 100px">
    	<div class="card-body">
    		
    		<form method="POST" action="<?php echo base_url('admin/dataMahasiswa/tambahDataAksi')?>">

    			<div class="form-group">
    				<label>NIM</label>
    				<input type="text" name="nim" class="form-control">
    				<?php echo form_error('nim', '<div class="text-small text-danger"></div>') ?>
    			</div>

    			<div class="form-group">
    				<label>Nama Mahasiswa</label>
    				<input type="text" name="nama_mahasiswa" class="form-control">
    				<?php echo form_error('nama_mahasiswa', '<div class="text-small text-danger"></div>')?>
    			</div>

    			<div class="form-group">
    				<label>Jurusan</label>
    				<input type="text" name="jurusan" class="form-control">
    				<?php echo form_error('jurusan', '<div class="text-small text-danger"></div>')?>
    			</div>

    			<div class="form-group">
    				<label>Posko</label>
    				<input type="text" name="posko_kkt" class="form-control">
    				<?php echo form_error('posko_kkt', '<div class="text-small text-danger"></div>')?>
    			</div>
    			<button type="submit" class="btn btn-success">Submit</button>

    	</div>
    </div>


</div>



