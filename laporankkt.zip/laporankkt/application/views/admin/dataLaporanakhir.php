<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>


    <a class="btn btn-sm btn-success mb-3" href="<?php echo base_url('admin/dataLaporanakhir/tambahData') ?>"><i class="fas fa-plus">Tambah Laporan</i></a>
    <?php echo $this->session->flashdata('pesan')?>
    <table class="table table-bordered table-striped mt-2">
    	<tr>
    		<th class="text-center">No</th>
    		<th class="text-center">Tanggal Laporan</th>
    		<th class="text-center">Posko</th>
    		<th class="text-center">DPL</th>
    		<th class="text-center">Dosen Pengawas</th>
            <th class="text-center">Foto Kegiatan Tematik</th>
            <th class="text-center">Foto Kegiatan Non Tematik</th>
            <th class="text-center">Foto Kunjungan DPL</th>
    		<th class="text-center">Foto Kunjungan Pengawas</th>
            <th class="text-center">Foto Peserta KKT</th>
            <th class="text-center">Url Video KKT</th>
    		<th class="text-center">Action</th>
    	</tr>
            <?php  $no=1; foreach($laporanAkhir as $a) : ?>
            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $a->tanggal_laporan?></td>
                <td><?php echo $a->posko?></td>
                <td><?php echo $a->dpl?></td>
                <td><?php echo $a->dosenpengawas?></td>
                <td><img src="<?php echo base_url().'assets/photo/'.$a->$kegiatan_tematik ?>"></td>
                <td><img src="<?php echo base_url().'assets/photo/'.$a->$kegiatan_nontematik ?>"></td>
                <td><img src="<?php echo base_url().'assets/photo/'.$a->$kunjungan_dpl ?>" width="50px" ></td>
                <td><img src="<?php echo base_url().'assets/photo/'.$a->$kunjungan_dosenpengawas ?>" width="50px"></td>
                <td><img src="<?php echo base_url().'assets/photo/'.$a->$foto_pesertakkt ?>" width="50px"></td>
                <td><?php echo $a->url_videokkt?></td>
                <td></td>
                <td>
                    <center>
                        <a class="btn btn-sm btn-primary" href="<?php echo base_url('admin/dataLaporanakhir/updateData/'.$a->id_laporanakhir) ?>"><i class="fas fa-edit"></i></a>
                        <a onclick="return confirm('Yakin Hapus')" class="btn btn-sm btn-danger" href="<?php echo base_url('admin/dataLaporanakhir/deleteData/'.$a->id_laporanakhir) ?>"><i class="fas fa-trash"></i></a>
                    </center>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>


</div>