
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>


    <div class="card" style="width: 60%; margin-bottom: 100px">
        <div class="card-body">
            
            <?php foreach ($laporanHarian as $j): ?>
            <form method="POST" action="<?php echo base_url('admin/dataLaporanharian/updateDataAksi')?>">

                <div class="form-group">
                    <label>Tanggal Laporan</label>
                    <input type="hidden" name="id_laporanharian" class="form-control" value="<?php echo $j->id_laporanharian ?>">
                    <input type="date" name="tanggal_laporan" class="form-control" value="<?php echo $j->tanggal_laporan ?>">
                    <?php echo form_error('tanggal_laporan', '<div class="text-small text-danger"></div>') ?>
                </div>

                <div class="form-group">
                    <label>Posko</label>
                    <input type="text" name="Posko" class="form-control" value="<?php echo $j->posko ?>">
                    <?php echo form_error('posko', '<div class="text-small text-danger"></div>')?>
                </div>

                <div class="form-group">
                    <label>DPL</label>
                    <input type="text" name="DPL" class="form-control" value="<?php echo $j->dpl ?>">
                    <?php echo form_error('dpl', '<div class="text-small text-danger"></div>')?>
                </div>

                <div class="form-group">
                    <label>Dosen Pengawas</label>
                    <input type="text" name="dosenpengawas" class="form-control" value="<?php echo $j->dosenpengawas ?>">
                    <?php echo form_error('dosenpengawas', '<div class="text-small text-danger"></div>')?>
                </div>

                <div class="form-group">
                    <label>Komentar Kegiatan</label>
                    <input type="text" name="komentarkegiatan" class="form-control" value="<?php echo $j->komentarkegiatan ?>">
                    <?php echo form_error('komenytarkegiatan', '<div class="text-small text-danger"></div>')?>
                </div>

                 <div class="form-group">
                    <label>Laporan</label>
                    <input type="file" name="laporan" class="form-control" value="<?php echo $j->laporan ?>">
                    <?php echo form_error('laporan', '<div class="text-small text-danger"></div>')?>
                </div>

                <button type="submit" class="btn btn-success">Submit</button>

            </form>
        <?php endforeach; ?>
        </div>
    </div>


</div>



