<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

    <!-- MyCSS -->
    <link rel="stylesheet" href="style.css">
    
    <title>LaporanKKT</title>
  </head>
<section id="LKHI">
    <div class="card">
      <h5 class="card-header bg-danger">Laporan Kegiatan Harian KKT</h5>
      <div class="card-body ">
        <h5 class="card-title">Keterangan</h5>
        <p class="card-text">Laporan mahasiswa merupakan fasilitas yang dapat digunakan untuk monitoring dan evaluasi mahasiswa selama KKT</p>
        <p> Posko <select class="form-select" aria-label="Default select example">
          <option selected>Posko</option>
          <option value="1">MINSEL</option>
          <option value="2">MANADO</option>
          <option value="3">MINAHASA</option>
          <option value="1">MITRA</option>
          <option value="2">MINUT</option>
          <option value="3">TOMOHON</option>
        </select> </p>
        <p> Dosen Pembimbing Lapangan <select class="form-select" aria-label="Default select example">
          <option selected>DPL</option>
          <option value="1">Yaulie Rindengan, ST., M.Sc., MM</option>
          <option value="2">Rudolf S. Mamengko., SH., MH</option>
          <option value="3">Ir. Arie Lumenta, MT</option>
          <option value="4">Stanley Karouw, ST., MTI., MSCS</option>
        </select> </p>
        <p> Dosen Pengawas <select class="form-select" aria-label="Default select example">
          <option selected>Dosen Pengawas</option>
          <option value="1">Ir. Adrie Abram Sajow, M.Si</option>
          <option value="2">Max K. Sondakh, Jr., SH., MH</option>
          <option value="3">Dr. Jessy J. Pondaag, SE., M.Si</option>
          <option value="4">Prof. Dr. Drs. William Agustus Areros., M.Si</option>
        </select> </p>
        <div class="mb-3">
          <label for="formFile" class="form-label">Laporan Kegiatan Harian</label>
          <input class="form-control" type="file" id="formFile"></div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Menurut anda, bagaimana pelaksanaan KKT di Posko anda (berikan tanggapan dalam bentuk verbal)</label>
          <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
        </div>
        <a href="#" class="btn btn-primary">Submit</a>
      </div>
    </div>
    </section>