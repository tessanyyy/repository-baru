<section class="jumbotron">
      <br>
      <br>
      <h1 class="display-4">KULIAH KERJA TERPADU</h1>
      <p class="lead">Fasilitas ini dapat digunakan untuk Monitoring dan Evaluasi KKT.</p>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <p class="tutup">www.unsrat.ac.id</p>
</section>